/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.reservation.system;

/**
 *
 * @author A.Santos
 */

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Connections {
    
    
     public static void main(String[] args) {
       try{
           Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver
           Connection Connections;
           Connections = DriverManager.getConnection("jdbc:ucanaccess://D:\\Signup.accdb");
              System.out.println("Connected Successfully");
 
          }catch(ClassNotFoundException | SQLException e){
              System.out.println("Error in connection");
          }
         
}

    Statement createStatement() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}